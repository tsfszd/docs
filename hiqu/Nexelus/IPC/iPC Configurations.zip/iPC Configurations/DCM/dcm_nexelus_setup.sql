SET NOCOUNT ON
INSERT INTO pdd_lookup_ipc_entities_Detail
	([record_id],[column_1],[column_2],[column_3],[column_4],[column_5],[column_6])
VALUES
	(33,'2992','Vanguard Group - DFA','','','TMK_DCM_4875155','');