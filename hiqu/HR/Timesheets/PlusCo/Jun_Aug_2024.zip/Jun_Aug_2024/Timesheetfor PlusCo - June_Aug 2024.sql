insert into pld_transactions
(company_code, level2_key, level3_key, transaction_id, applied_date, line_id, trx_type, resource_id, Res_usage_code, units, location_code, org_unit, task_code, comments, nonbill_flag, submitted_flag, submitted_date, upload_flag, upload_date, res_type, vendor_id, payment_code, payment_name, currency_code, currency_conversion_rate, allocation_prc, amount, amount_home, amount_billable, receipt_flag, reimbursment_flag, parent_id, record_id, trx_level, create_id, create_date, modify_date, modify_id, gst_tax_amt, gst_tax_code, net_amount, pmt_vendor_code, approval_flag, approval_comment, approved_by, approval_date, mail_date, timestamp, extra_param_1, extra_param_2, business_reason, finalise_flag, finalised_by, finalised_date) VALUES
(1, 'ps000457 ', 'Time Billable', '8dc83b79f5713bd0', '6/3/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5.5, 'Pakistan', 'DevEng', NULL, 'Optimization Bug fixes.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/3/2024 10:26:25 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA287', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc847f636faa630', '6/4/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Estimation and tasks understanding.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/4/2024 10:16:24 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA289', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc847f636faa652', '6/4/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'Optimization Bug Fixes.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/4/2024 10:16:24 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA28B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc85454258370e0', '6/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'UAT Sync data', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/5/2024 9:52:49 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA290', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc85454258370f1', '6/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'Optimization Bug tracking for revision not creating.
Bugs verification from QA.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/5/2024 9:52:49 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA291', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc86132bef74f60', '6/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Internal meeting and discussion with team', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/6/2024 10:26:48 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA293', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc86132bef74f71', '6/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'Bug fixes and deployment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/6/2024 10:26:48 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA294', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc86c31cf666420', '6/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Morning meeting.
Discussion with team on issues', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/7/2024 7:26:14 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA296', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc86c31cf666431', '6/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'IO PO amount and consumed amount issue in posting invoices.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/7/2024 7:26:14 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA297', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc86c31cf666442', '6/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Code review and merge code and deployment over AZF', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/7/2024 7:26:14 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA298', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc86c31cf666453', '6/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'Optimization issues review and fixes', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/7/2024 7:26:14 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA299', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc89310841effd0', '6/10/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Optimization Rule bug fixes.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/10/2024 9:38:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA29F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8a8a5d43532f0', '6/11/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Optimization bug fixes and review for changes in azure forms.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/12/2024 2:50:05 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2A4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8a8a709e207b0', '6/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'Azure forms model creation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/12/2024 2:50:37 AM', '6/12/2024 9:03:17 AM', 'imranq', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2AA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8b94748ed7760', '6/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Move files to S3 after recognition', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/13/2024 10:34:50 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2AC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8b94748ed7771', '6/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'date format issue on UAT', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/13/2024 10:34:50 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2AD', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8c440be7774f0', '6/14/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'QA02 and UAT upgrade', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/14/2024 7:31:46 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2B4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8c442887092f1', '6/14/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Morning meeting.
Discussion with Asad on tasks.
discussion with Abid on issues and working.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/14/2024 7:32:34 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2B6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8fae8c4f2f8c0', '6/17/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Eid ul azha', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/18/2024 3:51:42 PM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2BF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8fae8c4f2f8d1', '6/18/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Eid ul azha', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/18/2024 3:51:42 PM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2C0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc8fae8c4f2f8e2', '6/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Eid ul azha', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/18/2024 3:51:42 PM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2C1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc9108beb357500', '6/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Morning meeting.
Discussion on Apworks and Issues.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/20/2024 9:09:52 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2C3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc9108beb357511', '6/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'ISSUE 17401

ISSUE 17399', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/20/2024 9:09:52 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2C4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc91a78d76d5010', '6/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Morning meeting.
Discussion on production failure
discussion with farooq on Optimization', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/21/2024 4:06:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2C6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc91a78d76d5021', '6/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'Optimization fixes.
Review bugs with media plan issue.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/21/2024 4:06:39 AM', '6/21/2024 9:42:17 AM', 'imranq', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2CA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc942cc799780e0', '6/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Optimization Bug Fixes', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/24/2024 9:05:22 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2CC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc94f9c6981cc20', '6/25/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Approval in optimization fixes for status check', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/25/2024 9:32:48 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2CE', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc95c1bb58d2fb0', '6/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Term code loading with vendor and client code.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/26/2024 9:24:08 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2D4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc9684a16a41130', '6/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Terms loading for I section based on client and vendor', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/27/2024 8:39:16 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA2D7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc974e0088e0fb0', '6/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Morning meeting.
Team discussion on New environment updates.
team discussion on hand over AZF scanner', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/28/2024 8:40:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA336', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc974e0088e0fc1', '6/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'QA and lambda functions updates with issue recognition', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '6/28/2024 8:40:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCA337', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc99b67c13a2840', '7/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Domain transfer meeting.
Internal meeting on handing over and code understanding.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '7/1/2024 10:13:42 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCC0DA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc99b67c13a2851', '7/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Remove delivery from production before Sync.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '7/1/2024 10:13:42 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCC0DB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc9a7078517eaa0', '7/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Domain transfer', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '7/2/2024 8:25:02 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCC1C6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dc9a7078517eab1', '7/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Sync issue', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'imranq', '7/2/2024 8:25:02 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCC1C7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7cd339e9fb0', '6/10/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meetings and working on', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:16:23 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCFDAB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7cd339e9fc1', '6/11/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meetings and working on', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:16:23 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDCFDAC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7e52957ca80', '6/17/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:27:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0036', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7e52957ca91', '6/18/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:27:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0037', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7e52957caa2', '6/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:27:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0038', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7e52957cab3', '6/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:27:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0039', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7e52957cac4', '6/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:27:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD003A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7e52957cae6', '6/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'RE: Nexus mobile app (NEX 17462)
RE: Sandbox: APwork Japan Access', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:27:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD003C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7e52957caf7', '6/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'RE: Nexus mobile app (NEX 17462)
RE: Sandbox: APwork Japan Access', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:27:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD003D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7ec009b4820', '6/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:30:10 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0065', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7ec009b4831', '6/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:30:10 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0066', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7ec009b4842', '6/25/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'RE: Propel health AP Works', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:30:10 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0067', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7ec009b4853', '6/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: ApWorks Azure AI Deployment 2024.2', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:30:10 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0068', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb78587e0', '7/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'FW: ApWorks Azure AI Deployment 2024.2
RE: APWorkflow -->Report--> Vendor Invoices (NEX 17404)
RE: MIssing invoice Bidtellect CM30042 Voucher #VCHUS00262 (NEX 17521)
FW: Propel health AP Works', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD006F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb78587f1', '7/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'FW: ApWorks Azure AI Deployment 2024.2
RE: APWorkflow -->Report--> Vendor Invoices (NEX 17404)
RE: MIssing invoice Bidtellect CM30042 Voucher #VCHUS00262 (NEX 17521)
FW: Propel health AP Works', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0070', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb7858802', '7/3/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: ApWorks Azure AI Deployment 2024.2
RE: ApWorks Azure AI Deployment 2024.2', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0071', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb7858813', '7/4/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: APWorkflow -->Report--> Vendor Invoices (NEX 17404)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0072', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb7858835', '7/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meeting and emails', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0073', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb7858846', '7/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meeting and emails', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0074', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb7858857', '7/3/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meeting and emails', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0075', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb7858868', '7/4/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meeting and emails', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0076', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf7fcb7858879', '7/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'meeting and emails', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0077', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8127eadcd47', '7/11/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meeting and emails', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:47:23 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD00DC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8127eadcd58', '7/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'meeting and emails', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:47:23 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD00DD', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8c50', '6/3/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0211', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8c61', '6/4/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0212', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8c72', '6/5/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0213', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8c83', '6/6/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0214', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8c94', '6/7/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0215', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8ca5', '6/3/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0216', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8cb6', '6/4/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0217', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8cc7', '6/5/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0218', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8cd8', '6/6/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0219', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83b469d8ce9', '6/3/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD021A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b94660', '6/10/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0229', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b94671', '6/11/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD022A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b94682', '6/12/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD022B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b94693', '6/13/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD022C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b946a4', '6/14/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD022D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b946b5', '6/10/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD022E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b946c6', '6/11/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD022F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b946d7', '6/12/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0230', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b946e8', '6/13/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0231', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf83ba2b946f9', '6/10/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0232', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e9903f0', '6/17/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0241', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990401', '6/18/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0242', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990412', '6/19/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0243', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990423', '6/20/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0244', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990434', '6/21/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0245', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990445', '6/17/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0246', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990456', '6/18/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0247', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990467', '6/19/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0248', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990478', '6/20/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0249', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8415e990489', '6/17/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD024A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb99450', '6/24/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0259', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb99461', '6/25/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD025A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb99472', '6/26/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD025B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb99483', '6/27/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD025C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb99494', '6/28/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD025D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb994a5', '6/24/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD025E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb994b6', '6/25/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD025F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb994c7', '6/26/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0260', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb994d8', '6/27/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0261', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf841dcb994e9', '6/24/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0262', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b6516730', '7/1/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1771', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b6516741', '7/2/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1772', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b6516752', '7/3/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1773', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b6516763', '7/4/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1774', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b6516774', '7/5/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1775', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b6516785', '7/1/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1776', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b6516796', '7/2/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1777', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b65167a7', '7/3/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1778', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b65167b8', '7/4/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1779', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf847b65167c9', '7/1/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD177A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7ac0', '7/8/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:51 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1688', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7ad1', '7/9/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:51 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1689', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7ae2', '7/10/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:51 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD168A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7af3', '7/11/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD168B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7b04', '7/12/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD168C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7b15', '7/8/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD168D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7b26', '7/9/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD168E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7b37', '7/10/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD168F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7b48', '7/11/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1690', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854601a7b59', '7/8/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1691', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f4380', '7/15/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16B5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f4391', '7/16/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16B6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f43a2', '7/17/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16B7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f43b3', '7/18/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16B8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f43c4', '7/19/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Phase 1 discussion over documentations finding cases that are not as per documentation', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16B9', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f43d5', '7/15/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'documentations related questions', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16BA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f43e6', '7/16/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'test cases according to the document and flow', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16BB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f43f7', '7/17/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16BC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf854f56f4408', '7/18/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'discussion with the lead over major changes', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16BD', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e92d0', '7/22/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02D3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e92e1', '7/23/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02D4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e92f2', '7/24/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02D5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e9303', '7/25/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02D6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e9314', '7/26/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02D7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e9325', '7/22/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02D8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e9336', '7/23/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02D9', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e9347', '7/24/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02DA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e9358', '7/25/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02DB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf85b294e9369', '7/22/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02DC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf862ccbac710', '7/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'FW: APWorkflow -->Report--> Vendor Invoices (NEX 17404)
RE: APWorkflow -->Report--> Vendor Invoices (NEX 17404)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 4:23:19 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0342', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcaf8734766f6e0', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Analysis of new requirements for plus company', 0, 1, '7/30/2024 7:41:52 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '7/29/2024 4:30:41 AM', '7/30/2024 7:41:52 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04D7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcafa92fa8ec010', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Currently working on Assign Multiple PO to Invoice Line. Add new Search Icon. When user clicks for IO/PO number, popup Dialog will allow selecting more than one IO/PO number. This will be allowed only if searched through Header search icon else Only single selection will be applicable of IO/PO Number Done', 0, 1, '7/29/2024 8:34:02 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '7/29/2024 8:33:56 AM', '7/29/2024 8:34:02 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD040F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb032fcc0af0c0', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Analysis of adding discount field. and how to add it to the document.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '7/30/2024 1:00:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD049D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb032fcc0af0d1', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'debugging and testing of shipyard posting issue.', 1, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '7/30/2024 1:00:21 AM', '7/30/2024 1:24:41 AM', 'asadm', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04A1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb032fcc0af0e2', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'syncing data in theshipyard uat enviroment.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '7/30/2024 1:00:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD049F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb032fcc0af0f3', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'added discount field and setting it up for data.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '7/30/2024 1:00:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04A0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb03662f8b0fa1', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'meeting about how discount works, posting issue on theshipyard and about sprint 2 tasks.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '7/30/2024 1:24:41 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04A2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb04cb8dc3d120', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Review and discuss schedule tasks with Team', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '7/30/2024 4:04:34 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04C2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb04cb8dc3d142', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Discussion Plus Co Scope document', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '7/30/2024 4:04:34 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04C4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb0757ae8e8ed0', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'analysis of bug 17664', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '7/30/2024 8:56:20 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04E2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb075ca38857d0', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'task auto approve invoice.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '7/30/2024 8:58:33 AM', '7/30/2024 8:58:55 AM', 'asadm', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04E5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb075ca38857e1', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'fixed issues 17661,17662,17663', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '7/30/2024 8:58:33 AM', '7/30/2024 8:58:55 AM', 'asadm', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD04E6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb100e38704d30', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Task Title: Implement Multiple IO/PO Number Selection Verification and Invoice Line Duplication
Objective: To enhance the application by verifying the sum of remaining amounts for selected IO/PO numbers against the invoice line amount and creating additional invoice lines if the amounts match.
Description: When a user selects a single IO/PO number, the current behavior of the application remains unchanged. However, if the user selects multiple IO/PO numbers, the system will:
Verify if the sum of the remaining amounts for the selected IO/PO numbers is equal to the invoice line amount.
If the amounts do not match, display a warning message to the user.
If the amounts match, create additional copies of the invoice lines (equal to the sum of selected PO lines minus one).
Assign the selected IO/PO numbers to the original invoice line and the newly created lines accordingly.
Verified the application behavior for single IO/PO number selection remains unchanged
Tested the new functionality with multiple IO/PO number selections
Validated the verification check, warning message display, and invoice line creation for matched and mismatched amounts', 0, 1, '7/31/2024 1:34:20 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '7/31/2024 1:34:15 AM', '7/31/2024 1:34:20 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0547', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb12bddebc1b41', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Release management.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '7/31/2024 6:41:54 AM', '8/2/2024 1:22:44 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0733', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb132ae9b4b1d0', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'Task Title: Implement Drag-and-Drop File Upload for Invoice Queue (waiting to be scanned) Grid
Objective: Enhance the user experience by allowing users to drag and drop files directly into the ''Invoice Queue (waiting to be scanned)'' grid for upload. The drop zone should be visible only within the ''Invoice Queue (waiting to be scanned)'' grid and should adjust correctly to different screen sizes.
Add the JavaScript code to ensure the container of the grid is relatively positioned so that the absolute positioning of the drop zone works correctly.
Implement event handlers for onDragOver, onDragLeave, and onDrop to manage the drag-and-drop functionality.
Ensure the drop zone is only shown when a file is dragged over the ''Invoice Queue (waiting to be scanned)'' grid.
Ensured that this area is not displayed on any other grid within the application.', 0, 1, '7/31/2024 8:07:29 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '7/31/2024 7:30:41 AM', '7/31/2024 8:07:29 AM', 'arslank', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD05A5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb137aae8991c2', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Understanding the Drag-and-Drop Requirement:
Current Behavior: Users currently do not have the ability to drag and drop files directly into the ''Invoice Queue'' grid for upload.
Expected Behavior: Users should be able to drag and drop files into the ''Invoice Queue'' grid, and the drop zone should be displayed only within this grid, not covering any other grid or part of the screen.
Possible Challenges:
Ensuring the drop zone is confined to the ''Invoice Queue'' grid.
Making sure the drop zone adjusts correctly to different screen sizes.
Handling the file upload process seamlessly once the file is dropped.', 0, 1, '7/31/2024 8:07:29 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '7/31/2024 8:06:22 AM', '7/31/2024 8:07:29 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD05A6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb137d017553d1', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Task Title: Fix PO Code Search and Selection of PO Number into the Search field
Objective: Resolve issues related to PO Code search in Production invoices and implement various enhancements, including fixing errors when selecting PO Numbers from the grid and making title.
Fix PO Code Search Error:
Issue: When searching for a PO Code, an error was encountered.
Solution: Identify the root cause of the error in the search functionality and apply the necessary fixes to ensure the search works correctly.
Ensure the search results are displayed without errors.
Fix Error When Selecting PO Number from Grid:
Issue: When a user selects a PO Number from the grid and assigns it to the search field, an error was encountered.
Solution: Identify and fix the issue to ensure the PO Number selection works correctly.
Ensure the selected PO Number is assigned to the search field without errors.', 0, 1, '7/31/2024 8:07:29 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '7/31/2024 8:07:25 AM', '7/31/2024 8:07:29 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD05A7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb13b2f76b1a21', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Line Level Approval documentation - Plus Company Enhancement', 0, 1, '7/31/2024 8:31:37 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '7/31/2024 8:31:33 AM', '7/31/2024 8:31:37 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD05AF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb13b6628b14e0', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Plus Company feature list discussion with Asim/Abid', 0, 1, '7/31/2024 8:34:06 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '7/31/2024 8:33:05 AM', '7/31/2024 8:34:06 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD05B5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb1c259638f520', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'development of sprint item invoice auto approval.
added check boxes in configuration section.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/1/2024 12:39:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD063F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb1c259638f531', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'sprint bug fixing.
model scanner.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/1/2024 12:39:06 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0640', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb1d20c06c52a0', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AP Works
 - Deployment 
 - Team assistance and their task review.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/1/2024 2:31:28 AM', '8/2/2024 1:22:44 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0734', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb202d7ca78ce1', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Emails', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/1/2024 8:20:45 AM', '8/1/2024 9:10:14 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD067E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2033e1cfe130', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Configuration Changes:
Added a configuration at the company level to allow invoice approval on either the header level or line level.
Conducted a thorough analysis of the requirements for header level approval.', 0, 1, '8/1/2024 8:48:25 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/1/2024 8:23:37 AM', '8/1/2024 8:48:25 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0679', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2033e1cfe141', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'Applied the same adjustments and implementations to the Production Invoices module.
Verified that the drop zone is only shown when a file is dragged over the ''Production Invoices'' grid and not displayed on any other grid within the module.
Multiple File Uploads:
Enabled the functionality to allow multiple files to be uploaded in both the Media Invoices and Production Invoices modules.
Ensured that the drag-and-drop functionality supports multiple file uploads.
Verified that the user interface and backend processes handle multiple file uploads correctly in both modules.
Adjusted the drop zone and related elements to be responsive to different screen sizes.
Ensured that when the screen size is small, a smaller drop document div is displayed.
Performed testing to ensure that the drag-and-drop functionality and the display of the drop zone work correctly across various screen sizes.
Conducted comprehensive testing to ensure that all implemented features work as expected.
Tested the drag-and-drop functionality for both single and multiple file uploads.
Verified the visibility and positioning of the drop zone in different modules and screen sizes.', 0, 1, '8/1/2024 8:48:25 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/1/2024 8:23:37 AM', '8/1/2024 8:48:25 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD067A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb209c0eb645f2', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Deployed Lambda on AWS
Resolved Framework issue.
Deployment for AP works hotfix [RE: APWorkflow -->Report--> Vendor Invoices (NEX 17404)]', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/1/2024 9:10:14 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD067F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2c23fc3cee40', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'vendor mapping fallback discussion.
identification of possible issues in vendor mapping.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/2/2024 7:10:54 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0745', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2c23fc3cee51', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'updated lambda function and fixed minor issue.
model scanner.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/2/2024 7:10:54 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0746', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2d2b5a7b44e0', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Identify the necessary changes in the database schema to support both approval levels.
Plan the migration scripts for the database changes.', 0, 1, '8/6/2024 1:05:16 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/2/2024 9:08:44 AM', '8/6/2024 1:05:16 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08CC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2d2b5a7b44f1', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'Design the user interface changes required to support the new approval configuration.
Implement the UI changes to allow users to select the approval level (header or line).
Update the invoice approval screens to reflect the selected approval level.
Integrate the frontend changes with the updated backend API.
Update the backend API to handle the new approval configuration.
Implement endpoints for setting and retrieving the approval', 0, 1, '8/6/2024 1:05:16 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/2/2024 9:08:44 AM', '8/6/2024 1:05:16 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08CD', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2f0ee208acf0', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'activation and deactivation of vendor map model.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/2/2024 12:45:03 PM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD074E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2f0ee208ad01', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'apworks multiple mapping insertion.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/2/2024 12:45:03 PM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD074F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb2f0ee208ad12', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'analyzing anomalous behavior of saving and scanning vendor map record and fixing it.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/2/2024 12:45:03 PM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0750', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb4ef0aa2254a0', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 0.5, 'Pakistan', 'DevEng', NULL, 'RE: Missing Invoice ( NEX 17614)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/5/2024 1:36:34 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD075B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb4ef0aa2254b1', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Project Plan updated
Discussion with Arshad, Tauseef, Asim on plan status', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/5/2024 1:36:34 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD075C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a94f0', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
Phase 2
 implementation and requirement analysis', 0, 1, '8/19/2024 6:43:26 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/19/2024 6:43:26 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1683', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a9501', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'shipyard', 0, 1, '8/19/2024 6:43:26 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/19/2024 6:43:26 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1684', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a9512', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 2 documentation understanding', 0, 1, '8/19/2024 6:43:26 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/19/2024 6:43:26 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1685', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a9523', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 2 testing and comparing with document', 0, 1, '8/19/2024 6:43:26 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/19/2024 6:43:26 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1686', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a9545', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a9556', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a9567', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a9578', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50c18f1a9589', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50f9a21c60f0', '7/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'RE: APWorkflow -->Report--> Vendor Invoices (NEX 17404)
RE: APWorkflow -->Report--> Vendor Invoices (NEX 17404)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/5/2024 5:29:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07F5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb50f9a21c6101', '7/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'meeting and discussions', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/5/2024 5:29:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07F6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb510fb05e4310', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: The Shipyard Deployment Checklist -  Apworks', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/5/2024 5:39:31 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0804', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb510fb05e4321', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'RE: Missing Invoice ( NEX 17614)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/5/2024 5:39:31 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0805', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb510fb05e4343', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/5/2024 5:39:31 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0806', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb510fb05e4354', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'RE: Missing Invoice ( NEX 17614)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/5/2024 5:39:31 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0807', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb529d2e55a6b0', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Plan changes.
Progress updates.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/5/2024 8:37:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD085C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb52ebbba12c70', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'missing invoice issue.
analyzed and re generated the missing invioce.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/5/2024 9:12:30 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0862', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb52ebbba12c81', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'apworks sprint 
table recognition and entry.
analyzed the requirements.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/5/2024 9:12:30 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0863', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb52ebbba12c92', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'bug fixing activity.
analyed and fixed issues.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/5/2024 9:12:30 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0864', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5b661b8ad300', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Create a new property Approval Level in the Media Invoice model.
Update the Media Invoice model to include the new Approval Level property.
Create a new method Get Approval Level in the Media Invoice Repository class to retrieve the approval level from the database.
Update the Save Media Invoice method in the Media Invoice Repository class to save the approval level to the database.
Update the Media Invoice view to display the approval level.
Update the Production Invoice view to hide the approval level.', 0, 1, '8/6/2024 1:23:52 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/6/2024 1:23:30 AM', '8/6/2024 1:23:52 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08D0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5b661b8ad311', '8/5/2024 12:00:00 AM', '1', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'Alter the table in the database to add a new column Approval Level with a data type of varchar(12).
Update the database schema to include the new column.
Update the stored procedure to include the Approval Level parameter.
Modify the stored procedure to save the Approval Level value to the Media Invoices table.
Modify the stored procedure to retrieve the Approval Level value from the Media Invoices table.', 0, 1, '8/6/2024 1:23:52 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/6/2024 1:23:30 AM', '8/6/2024 1:23:52 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08D1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5ba668b45ea3', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Analyze posting issue', 0, 1, '8/6/2024 1:52:22 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/6/2024 1:52:16 AM', '8/6/2024 1:52:22 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08DF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5ba668b45eb4', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Meeting on APWorks 2024.2 Items', 0, 1, '8/6/2024 1:52:22 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/6/2024 1:52:16 AM', '8/6/2024 1:52:22 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08E0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5ba668b45ec5', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Weekly meeting and support Meeting', 0, 1, '8/6/2024 1:52:22 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/6/2024 1:52:16 AM', '8/6/2024 1:52:22 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08E1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5baeaa4815d2', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Design Document for APWorks - Line Level Approval', 0, 1, '8/6/2024 1:56:02 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/6/2024 1:55:58 AM', '8/6/2024 1:56:02 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08EB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5baeaa4815e3', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Meeting on APWorks', 0, 1, '8/6/2024 1:56:02 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/6/2024 1:55:58 AM', '8/6/2024 1:56:02 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08EC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5f8b8032afc0', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'To implement functionality where if no customer is specified on the invoice, all invoice lines will be available for approval/rejection. Additionally, if the user saves an invoice with all invoice lines as rejected, the invoice approval status will revert back to the previous level.
Possibly add a column to track the previous approval status.
Implement logic to check if no customer is specified and make all invoice lines available for approval/rejection.
Implement logic to revert the invoice approval status if all invoice lines are rejected.
Update the UI to reflect the new approval/rejection logic for invoice lines.
Ensure the UI can handle the reverting of the invoice approval status.', 0, 1, '8/6/2024 9:18:26 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/6/2024 9:18:22 AM', '8/6/2024 9:18:26 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08F7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb5f8b8032afd1', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Modify stored procedures and related tables to include the approval_level functionality.
Identify all stored procedures and tables that need to be updated to support the approval_level feature.
Update the stored procedures to handle the approval_level parameter.
Test the changes locally to ensure they work as expected.
Prepare Scripts and send the updated stored procedures and table modifications to the Database Administrator (DBA) for approval.
Push the committed changes to the remote Git repository.', 0, 1, '8/6/2024 9:18:26 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/6/2024 9:18:22 AM', '8/6/2024 9:18:26 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08F8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb685971e10990', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AP Works Hot patch: RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/7/2024 2:06:46 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08FA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb685971e109a1', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Team assignment/reviews', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/7/2024 2:06:46 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD08FB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6bbf451972b0', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'analysed and produced issues in db flow on vendor mapping', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/7/2024 8:35:55 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0C9D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6bbf451972c1', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'testing model mapping , vendor mapping for new changes.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/7/2024 8:35:55 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0C9E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6bbf451972d2', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'updated flow
changes in procedure.
changes in model listing.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/7/2024 8:35:55 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0C9F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6bbf451972e3', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'model listing front end flow setting.

tested discount field and recognized known cases.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/7/2024 8:35:55 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0CA0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6bbf451972f4', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'reproduced and unit tested model listing for new changes.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/7/2024 8:35:55 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0CA1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6bbf45197305', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'fixed know issues', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/7/2024 8:35:55 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0CA2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6bde8a3ab080', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'To understand the code flow for approving and rejecting invoice documents, and to explore the stored procedures to find the logic behind these actions. Additionally, observe how the status of the invoice document changes upon approval and rejection.
Trace the code flow for approving an invoice document.
Identify the functions or methods involved in the approval process.
Trace the code flow for rejecting an invoice document.
Identify the functions or methods involved in the rejection process.
After understanding the approval and rejection flows, observe how the status of the invoice document changes.
Identify the database fields or variables that store the status of the invoice.
Note the status values before and after approval and rejection.
Locate the stored procedures related to invoice approval and rejection in the database.
Analyze the logic implemented in these stored procedures.
Identify any input parameters, conditions, and operations performed within these procedures.', 0, 1, '8/7/2024 8:49:58 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/7/2024 8:49:54 AM', '8/7/2024 8:49:58 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0CA7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6bde8a3ab091', '8/6/2024 12:00:00 AM', '1', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Locate the stored procedures behind these logics and identify the parameters and conditions upon these logics', 0, 1, '8/7/2024 8:49:58 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/7/2024 8:49:54 AM', '8/7/2024 8:49:58 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0CA8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb6be6637b1f40', '8/7/2024 12:00:00 AM', '1', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Identify the stored procedure(s) responsible for handling invoice document approval and rejection.
Review the stored procedure code, paying attention to the following:
Input parameters and their data types.
SQL queries and joins used to retrieve and update data.
Conditional statements and business logic used to determine approval or rejection.
Error handling and logging mechanisms.
Determine how the stored procedure updates the invoice document status and any related tables or fields.
Investigate how the invoice document status is updated after approval or rejection.
Identify the specific database table(s) and field(s) updated, as well as any related triggers or cascading effects.', 0, 1, '8/7/2024 8:53:31 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/7/2024 8:53:25 AM', '8/7/2024 8:53:31 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0CAA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb74de19c71f10', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1.5, 'Pakistan', 'DevEng', NULL, 'AP Works Hot patch: RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/8/2024 2:00:30 AM', '8/8/2024 2:07:56 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0CB4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb74edb596dd00', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'RE: Activity Sync Needed: Not Appearing in APWorks', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/8/2024 2:07:29 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0CB3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb7b94f27d5a22', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Plus Co Items', 0, 1, '8/8/2024 2:49:37 PM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/8/2024 2:49:30 PM', '8/8/2024 2:49:37 PM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0D06', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb7b94f27d5a33', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Review Split Functionality with Asim/Abid
Review Team Progress on APWorks', 0, 1, '8/8/2024 2:49:37 PM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/8/2024 2:49:30 PM', '8/8/2024 2:49:37 PM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0D07', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb7b9c48519684', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Revised Line Item Approval Document', 0, 1, '8/8/2024 2:52:53 PM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/8/2024 2:52:47 PM', '8/8/2024 2:52:53 PM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0D14', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb8401768f90e0', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AP Works Hot patch: RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/9/2024 6:54:19 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0D55', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb8401768f90f1', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Brainstorming and team discussion on following items
 - Line level approval
 - Currency rate changes.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/9/2024 6:54:19 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0D56', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb84047dad90d0', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2.5, 'Pakistan', 'DevEng', NULL, 'Dotnet technical guidance on development tasks
 - Line level approval
 - Table parsing while invoice scanning
 - Attachment on purchase order.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/9/2024 6:55:40 AM', '8/9/2024 6:57:21 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0D59', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb854108b3ef40', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'After several management meetings, the procedure for handling invoice documents has been updated. The key changes are as follows:
The approval and rejection process for invoice documents has been streamlined.
Specific actions have been defined for rejected invoices, including where they will be stored or how they will be handled.
The review process now includes a detailed examination of database stored procedures and related tables.
Review of Approval and Rejection Levels
Approval Process: When an invoice document is approved, it will be marked as such in the database and moved to the approved invoices section.
Rejection Process: If an invoice document is rejected, it will be flagged in the database and moved to a designated rejected invoices section for further review or correction.
Database Stored Procedures and Tables
Stored Procedures: Review and ensure that the stored procedures handling invoice approvals and rejections are functioning correctly. This includes procedures for updating invoice statuses and moving invoices between tables.
Tables: Explore and document the tables involved in the invoice process, such as:
Invoices: Stores all invoice documents.
ApprovedInvoices: Stores approved invoices.
RejectedInvoices: Stores rejected invoices.', 0, 1, '8/9/2024 9:17:24 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/9/2024 9:17:17 AM', '8/9/2024 9:17:24 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0DA7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb854108b3ef51', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'UI Updates with Icons and CSS Styling
Icons for Approval and Rejection: Add icons to the UI for approving and rejecting invoice lines.
Use a checkmark icon for approval.
Use a cross or X icon for rejection.
CSS Styling: Apply CSS styling to ensure the icons are visually appealing and consistent with the overall design of the application.', 0, 1, '8/9/2024 9:17:24 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/9/2024 9:17:17 AM', '8/9/2024 9:17:24 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0DA8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcb854c7e9f81a0', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Show Approval Column in Invoice Detail Grid
Added an Approval column to the invoice detail grid.
Ensure that the Approval column correctly displays the approval or rejection status, along with the user who performed the action. Add a history icon to the column to view the approval/rejection history.
2. Backend Functionality to Save Approval Column
Implemented backend functionality to save the Approval column data into the database.
Update the models and data access layer to support saving and retrieving the Approval column data.
CSS Styling
 Applied CSS to the dropdown and history icon.
Ensure the CSS styling is consistent and visually appealing.
Update Models and Data Access Layer:
Modify the models to include fields for approval status, approved/rejected by, and history.
Update the data access layer to handle the new fields.', 0, 1, '8/9/2024 9:22:32 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/9/2024 9:22:25 AM', '8/9/2024 9:22:32 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0DAA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcba668d8637330', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'vendor mapping table addition in details', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/12/2024 12:34:40 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0E30', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcba668d8637341', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'bug fixing in sprint 2', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/12/2024 12:34:40 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0E31', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcba668d8637352', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'bug fixing in sprint 2', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/12/2024 12:34:40 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0E32', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbaad36a18beb0', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'Line Level Approval Task:
Approval Column, Comments Icon, and History Icons:
Added an approval column to the line level approval interface.
Integrated a comments icon to allow users to add comments.
Added history icons to track the approval history of each line item.
Approval and Rejection Icons:
Added two new icons for approval and rejection actions.
Implemented functionality to open a popup with a text area when either the approval or rejection icon is clicked.
The popup allows users to add comments related to their approval or rejection decision.
Clicking the ''Ok'' button in the popup saves the status of the line item along with the comments.', 0, 1, '8/12/2024 9:00:33 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/12/2024 9:00:28 AM', '8/12/2024 9:00:33 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0EC5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbaad36a18bec1', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Bug Fix: Split Invoice Lines:
Remaining Amount and ioInvoiceAmount Issue:
Investigated and resolved a bug reported by the QA team related to split invoice lines.
Fixed issues concerning the remaining amount and ioInvoiceAmount calculations to ensure accurate financial data.', 0, 1, '8/12/2024 9:00:33 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/12/2024 9:00:28 AM', '8/12/2024 9:00:33 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0EC6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbaafe72da0830', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AP Works Hot patch: RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/12/2024 9:19:44 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0ECA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbab00905cba20', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'AP Works Hot patch: RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/12/2024 9:20:40 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0ECC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbab4ca7b87211', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Design Document update for Imran Review', 0, 1, '8/12/2024 9:54:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/12/2024 9:54:43 AM', '8/12/2024 9:54:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0ED4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbab4ca7b87222', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Dev and Design Meeting', 0, 1, '8/12/2024 9:54:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/12/2024 9:54:43 AM', '8/12/2024 9:54:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0ED5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbab5100b6dc41', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Review Cancel Invoice', 0, 1, '8/12/2024 9:56:45 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/12/2024 9:56:40 AM', '8/12/2024 9:56:45 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0EDC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbab5100b6dc52', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Design and Project Plan Review Meeting', 0, 1, '8/12/2024 9:56:45 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/12/2024 9:56:40 AM', '8/12/2024 9:56:45 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0EDD', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb74eda1ddac6', '8/6/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Worked on Apworks Axure AI Deployment 2024.2
RE: ApWorks Azure AI Deployment 2024.2
•	ISSUE 17653 : Model Mapping from Model Mapping UI -> Duplicate Issue
•	ISSUE 17665 : New Model from Model Mapping UI -> Invoice gets unrecognized when scanned', 0, 1, '8/19/2024 7:07:25 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/13/2024 8:50:05 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6774', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb74eda1ddad7', '8/7/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Worked on Apworks Axure AI Deployment 2024.2
RE: ApWorks Azure AI Deployment 2024.2
• Nexelus Notification: Invoice Status Change - Navigation link Issue (NEX 16669)', 0, 1, '8/19/2024 7:07:25 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/13/2024 8:50:05 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6776', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb74eda1ddae8', '8/8/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Worked on Apworks Axure AI Deployment 2024.2
RE: ApWorks Azure AI Deployment 2024.2
• Nexelus Notification: Invoice Status Change - Navigation link Issue (NEX 16669)', 0, 1, '8/19/2024 7:07:25 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/13/2024 8:50:05 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6778', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb74eda1ddaf9', '8/9/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Worked on Apworks Axure AI Deployment 2024.2
RE: ApWorks Azure AI Deployment 2024.2
• Nexelus Notification: Invoice Status Change - Navigation link Issue (NEX 16669)', 0, 1, '8/19/2024 7:07:25 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/13/2024 8:50:05 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD677A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb75481ff6150', '8/12/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: Documentation Content request 
Worked on documentation for Apworks
Started documenting points provided by Abid', 0, 1, '8/19/2024 7:07:30 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/13/2024 8:52:37 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD677C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb75481ff6161', '8/13/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: Documentation Content request 
Worked on documentation for Apworks
Started documenting points provided by Abid', 0, 1, '8/19/2024 7:07:30 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/13/2024 8:52:37 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD677E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c00', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 2', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F22', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c11', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 2, 3 working', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F23', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c22', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 2, 3 working', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F24', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c33', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 planning and test cases', 0, 1, '8/19/2024 6:30:43 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/19/2024 6:30:43 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD166B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c44', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 planning and test cases', 0, 1, '8/19/2024 6:30:43 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/19/2024 6:30:43 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD166C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c55', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 planning and test cases
closing QA items + document working 
flow corrections + item review', 0, 1, '8/19/2024 6:30:43 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/19/2024 6:30:43 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD166D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c66', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'deployment on QA for verification  
worked on tolerance for media 
worked on phase 3 model mapping 
previous issues reopened regarding basic validations 
questioning the document items due to unclear items written on document 
worked on merging IO and lines on media', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F28', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c77', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'deployment on QA for verification  
worked on tolerance for media 
worked on phase 3 model mapping 
previous issues reopened regarding basic validations 
questioning the document items due to unclear items written on document 
worked on merging IO and lines on media', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F29', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c88', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'support items worked with team', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F2A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb7596fd75c99', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'support items worked with team', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F2B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb77ab81bf890', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Add History Icon to Approval Status Column
Objective: Add a history icon to the Approval Status column in the invoice approval system.
Steps:
Identify the location of the Approval Status column in the codebase.
Add the history icon to the column.
Ensure the icon is properly styled and visible.
Implement Popup to Show History on Line Level Approval
Objective: Add a popup that displays the history of line-level approvals when the history icon is clicked.
Steps:
Create a popup component that can display the history details.
Fetch the history data from the backend when the history icon is clicked.
Populate the popup with the fetched data.
Ensure the popup is properly styled and functional.', 0, 1, '8/13/2024 9:09:49 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/13/2024 9:09:43 AM', '8/13/2024 9:09:49 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F31', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbb77ab81bf8a1', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Bug Fix: Incorrect Sum of Merged Lines/Amounts
Objective: Ensure the system calculates the correct sum when multiple lines are merged.
Steps:
Identify the function responsible for merging lines and calculating the sum.
Debug the function to find the root cause of the incorrect sum.
Fix the calculation logic to ensure the correct sum is displayed.
Test the fix by merging multiple lines and verifying the sum.
Bug Fix: Alert Message for Splitting Lines Without PO Selection
Objective: Display a proper alert message when attempting to split lines without selecting a PO.
Steps:
Identify the function that handles the line splitting logic.
Modify the function to check if a PO is selected before allowing the split.
Update the alert message to provide clear instructions to the user.
Test the fix by attempting to split lines without selecting a PO and verifying the alert message.
Bug Fix: Automatic Population of Total PO Amount
Objective: Ensure the system correctly populates the total PO amount in the amount field when a PO is selected.
Steps:
Identify the function that handles PO selection and amount population.
Debug the function to find any issues with the amount population logic.
Fix the logic to ensure the correct PO amount is populated.
Test the fix by selecting different POs and verifying the amount field.', 0, 1, '8/13/2024 9:09:49 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/13/2024 9:09:43 AM', '8/13/2024 9:09:49 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F32', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcda5ea1effc0', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)
 - Deployment for QA
 - Change request form created.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/15/2024 3:28:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F34', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcda5ea1effd1', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Line level document analysis and meeting', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/15/2024 3:28:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F35', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcfc565bcf3e4', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Daily Support Meeting
Plus Company Phase 3 feature review', 0, 1, '8/15/2024 7:32:00 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/15/2024 7:31:54 AM', '8/15/2024 7:32:00 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F47', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcfc565bcf3f5', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, '1. Plus Company requirements Review
2. Review APWorks progress', 0, 1, '8/15/2024 7:32:00 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/15/2024 7:31:54 AM', '8/15/2024 7:32:00 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F48', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcfe8e357ef40', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Discount field addition and unit testing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/15/2024 7:47:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F56', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcfe8e357ef51', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'addition of table into vendor mapping details.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/15/2024 7:47:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F57', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcfe8e357ef62', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'addition of table in vendormapping details', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/15/2024 7:47:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F58', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcfe8e357ef73', '8/14/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, '14 august national holiday', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/15/2024 7:47:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F59', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcfe8e357ef84', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'bug fixing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/15/2024 7:47:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F5A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbcfe8e357ef95', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'bug fixing reviewing issues and assigning back to qa.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/15/2024 7:47:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F5B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbd0da9bd6b2b0', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Discussion and estimation on below item
RE: APWorks and PlusCo - EDI Broadcast Invoices

2024.2: Team''s task reviews.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/15/2024 9:35:55 AM', '8/15/2024 9:36:32 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F6F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdb0737343ee0', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, '1. Daily Development Meeting
2. Daily Support Meeting', 0, 1, '8/16/2024 5:01:19 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/16/2024 5:01:12 AM', '8/16/2024 5:01:19 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0FE7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bd60', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1044', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bd71', '8/14/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1045', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bd82', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1046', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bd93', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1047', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bda4', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1048', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bdb5', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1049', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bdc6', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD104A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bdd7', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD104B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bde8', '8/14/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD104C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc5c16e1bdf9', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD104D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc6957a8fc00', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'Display the approval status column with both status ID and name, concatenated with ''pending''.
Front-End Changes:
Update the UI component (e.g., a table or grid) to display the approval status.
Modify the data binding logic to concatenate the status ID and name with ''pending''.
Back-End Changes:
Update the Save button functionality to accommodate the changes made in the frontend, business logic, and data access layers
Ensure the Save button saves the lines correctly with the updated approval status
Modify the status change functionality in the backend to approve or reject every selected line
Complete any remaining work necessary for saving the lines, including updating the database and ensuring data consistency', 0, 1, '8/16/2024 7:39:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/16/2024 7:39:38 AM', '8/16/2024 7:39:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1059', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc6957a8fc11', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Fix Bugs Related to Splitting and Merging Invoice Lines
Identify the bug causing issues with splitting invoice lines
Debug the code to determine the root cause of the issue
Fix the bug to ensure that invoice lines are split correctly and accurately
Test the fix to ensure it resolves the issue
Identify the bug causing issues with merging invoice lines
Debug the code to determine the root cause of the issue
Fix the bug to ensure that invoice lines are merged correctly and accurately
Test the fix to ensure it resolves the issue', 0, 1, '8/16/2024 7:39:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/16/2024 7:39:38 AM', '8/16/2024 7:39:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD105A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdc74ee919400', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Update Design and Style of Dialogue and Text Area Labels, and Fix Bugs in Approve/Reject Line Functionality.
Update the design and style of dialogue and text area labels and headings in the Approve and Reject line functionality
Ensure consistency with the overall UI design and style guide
Test the updates to ensure they are displayed correctly and are user-friendly
Update the positions of the approval and rejection buttons to improve the user experience
Ensure the buttons are easily accessible and visible to the user
Test the updates to ensure the buttons are displayed correctly and are functional
Identify and fix bugs related to the history icon and dialogue in the frontend and backend
Ensure the history icon and dialogue are displayed correctly and are functional
Test the fixes to ensure they resolve the issues
Identify and fix bugs related to the visibility of the approval and rejection buttons
Ensure the buttons are displayed correctly and are visible to the user when necessary
Test the fixes to ensure they resolve the issues
Hide header level comments from the UI to improve the user experience
Ensure the comments are not visible to the user
Test the updates to ensure the comments are hidden correctly', 0, 1, '8/16/2024 7:44:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/16/2024 7:44:49 AM', '8/16/2024 7:44:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD105C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbdf9a80fa0020', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'bug fixing in collaboration with db and qa team', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/16/2024 1:45:14 PM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1086', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9ca1a2b8140', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'verification of items provided AZF', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:11:51 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1088', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9ca1a2b8151', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'RE: Ads and Creative', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:11:51 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1089', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9ca1a2b8162', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'RE: documentation related questions ( ApWorks Azure AI Deployment 2024.2 )', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:11:51 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD108A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9ca1a2b8173', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'RE: SQL Server Migration  to 2019', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:11:51 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD108B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9dae19b5610', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'DON
Understaning requirnments and planning for DON upgrade', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:19:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1093', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9dae19b5621', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'DON
Understaning requirnments and planning for DON upgrade', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:19:22 AM', '8/17/2024 9:19:44 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD109D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9dae19b5632', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'FW: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)
RE: documentation related questions ( ApWorks Azure AI Deployment 2024.2 )', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:19:22 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1095', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9dae19b5643', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'FW: APWorks - Line Level Approval for media Invoice - understanding document
RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:19:22 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1096', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbe9dbb5381761', '8/17/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'DON Verification', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/17/2024 9:19:44 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD109E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbfff9c8bf6171', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: Documentation Content request 
Worked on documentation for Apworks
Started documenting points provided by Abid', 0, 1, '8/19/2024 7:07:30 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/19/2024 3:32:54 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6780', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcbfff9c8bf6182', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'RE: Documentation Content request 
Worked on documentation for Apworks
Started documenting points provided by Abid', 0, 1, '8/19/2024 7:07:30 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/19/2024 3:32:54 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6782', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc00f8221fd160', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, '1. Task: Reviewing Technical Requirements & Document Analysis of APworks New Functionalities
•	Reading and Analysing Functional Requirements: 3 hours
•	Planning Test Scenarios: 2 hours
•	Team Meeting and Discussion: 2 hours', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:26:42 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD11C7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01115f250b70', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Task: Test Planning & Strategy Development
•	Drafting Initial Test Plan for Invoice Editing Changes
Time Spent: 2 hours
•	Identifying Test Scenarios for Merge Invoice Lines & Assign Multiple PO to Invoice Line
Time Spent: 2 hours
•	Developing Test Cases for Auto Approval Feature
Time Spent: 2 hours
•	Reviewing Test Plan with Team & Incorporating Feedback
Time Spent: 2 hours', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:37:59 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD11EE', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01115f250b81', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Task: Test Case Creation
•	Writing Detailed Test Cases for Merge Invoice Lines (Positive and Negative Scenarios)
Time Spent: 3 hours
•	Writing Test Cases for Assign Multiple PO to Invoice Line
Time Spent: 2 hours
•	Writing Test Cases for Discount Amount Field Calculations
Time Spent: 2 hours
•	Peer Review of Test Cases with QA Team
Time Spent: 1 hour', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:37:59 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD11EF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01115f250b92', '8/8/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Task: Test Case Execution & Initial Testing
•	Executing Test Cases for Merge Invoice Lines
Time Spent: 3 hours
•	Recording Observations and Preliminary Bugs
Time Spent: 2 hours
•	Reporting Bugs to Development Team
Time Spent: 1 hour
•	Verification of bugs fixed by DEV
Time Spent: 2 hour', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:37:59 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD11F0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01115f250ba3', '8/9/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Task: Regression Testing & Bug Verification
•	Regression Testing for Invoice Editing Features Post Bug Fixes
Time Spent: 4 hours
•	Verifying Bug Fixes for Merge Invoice Lines
Time Spent: 2 hours
•	Verifying Bug Fixes for Assign Multiple PO to Invoice Line
Time Spent: 1 hour
•	Documenting Regression Test Results
Time Spent: 1 hour', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:37:59 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD11F1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc011f032fe700', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Task: Database Changes & Configuration Testing
•	Reviewing Database Changes for Invoice Auto Approval
Time Spent: 2 hours
•	Testing Database Configuration for Line Level Approval Feature
Time Spent: 3 hours
•	Documenting Test Results for Database Testing
Time Spent: 2 hours
•	Team Review Meeting for Database Changes
Time Spent: 1 hour', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:44:05 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD12AA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc011f032fe711', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'Task: Dashboard Changes Testing
•	Understanding Requirements for Dashboard Layout Expansion
Time Spent: 2 hours
•	Testing Dashboard Layout Expansion for Invoice Queue
Time Spent: 2 hours
•	Testing Dashboard Layout Expansion for Discrepant Invoices
Time Spent: 2 hours
•	Reporting Dashboard Issues to Development Team
Time Spent: 1 hour', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:44:05 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD12AB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc011f032fe722', '8/14/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Public Holiday - Independence day 2024', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:44:05 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD12AC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc011f032fe733', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, '•	Verification of Issues Moved to Testing
Time Spent: 3 hours
•	Regression Testing
Time Spent: 3 hours
•	Blockers Listing
Time Spent: 1 hour
•	Complete Process Run
Time Spent: 1 hours', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:44:05 AM', '8/19/2024 5:53:47 AM', 'ayeshaq', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD161F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc011f032fe744', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, '•	Team Meeting
Time Spent: 2 hours
•	Blockers Verification
Time Spent: 1 hour
•	Process Run for identification of new possible issues
Time Spent: 2 hours
•	Verification of issues moved to testing
Time Spent: 2 hours', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/19/2024 5:44:05 AM', '8/19/2024 5:53:47 AM', 'ayeshaq', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1620', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01928b0097a0', '8/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'phase 3 and QA blockers rechecking and testing', 0, 1, '8/19/2024 6:35:49 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/19/2024 6:35:46 AM', '8/19/2024 6:35:49 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1679', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01cf70aa9d15', '7/29/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'FW: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)
Worked on Tolerance Level Confirmation', 0, 1, '8/19/2024 7:07:19 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/19/2024 7:03:01 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD676A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01cf70aa9d26', '7/30/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'FW: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)
Worked on Tolerance Level Confirmation', 0, 1, '8/19/2024 7:07:19 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/19/2024 7:03:01 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD676C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01cf70aa9d37', '7/31/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'FW: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)
Worked on Tolerance Level Confirmation', 0, 1, '8/19/2024 7:07:19 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/19/2024 7:03:01 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD676E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01cf70aa9d48', '8/1/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'FW: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)
Worked on Tolerance Level Confirmation', 0, 1, '8/19/2024 7:07:19 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/19/2024 7:03:01 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6770', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc01cf70aa9d59', '8/2/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'FW: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)
Worked on Tolerance Level Confirmation', 0, 1, '8/19/2024 7:07:19 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/19/2024 7:03:01 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6772', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc0b6ba987a6b0', '8/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Verfication of issues moved to testing 
Time Spent: 1 hour
Auto Approval of invoice on media 
Time Spent: 4 hours
PO create and pull check on APworks 
Time Spent: 2 hour
Issue replication and discussion wiith Dev
Time Spent: 1 hour', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/20/2024 1:23:42 AM', '8/20/2024 1:25:21 AM', 'ayeshaq', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD178D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc0b751cc0aa30', '8/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'APWorks: Tolerance on Media Invoices.(Lambda changes) - 2hrs', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/20/2024 1:27:56 AM', '8/21/2024 12:39:34 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1EA2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc0f5f021cfc60', '8/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Phase 3 
Auto approval till last level 4 major bugs posted which are related to requirements and flow + previous bugs closed', 0, 1, '8/20/2024 8:56:13 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/20/2024 8:56:10 AM', '8/20/2024 8:56:13 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1E9D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc17985554dbd2', '8/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Working on Line Level Approval
Submit Line Status and get next level approval for Approval Status column
Apply Bussiness logic, Model and Data access layer changes to get and save Approval Status', 0, 1, '8/21/2024 12:43:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/21/2024 12:38:05 AM', '8/21/2024 12:43:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1EA6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc179ba5523b01', '8/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, '- APWorks > DotNet version changed to 6 from 7 for Lambda support. = 4hrs', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/21/2024 12:39:34 AM', '8/21/2024 6:19:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F13', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc17a48bf83540', '8/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'Working on Line Level Approval
Find the issues regarding the next level approval status and line status in stored procedure
Inform the DB Team and resolve the issues', 0, 1, '8/21/2024 12:43:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/21/2024 12:43:33 AM', '8/21/2024 12:43:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1EA7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc17a48bf83551', '8/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Line Level History
Working on Line Level History as it creates issues on Manage Invoice Document grid
Dialogue issue to be fixed from both end Line Level Approval and Manage Invoice Document', 0, 1, '8/21/2024 12:43:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/21/2024 12:43:33 AM', '8/21/2024 12:43:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1EA8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc17e39168efa0', '8/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'Fixed Issues Verification
Blocker resolve check
Auto Approval test -> bugs posting
Process run for media 
Time Spent: 4 hours', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/21/2024 1:11:44 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1EAA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc1a925dc496f1', '8/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, '- APWorks > DotNet version changed to 6 from 7 for Lambda support and deployment. = 3hrs', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/21/2024 6:19:00 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F14', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc1b48309357d0', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'APWorks: Tolerance on Media Invoices.(Lambda changes) - Bug fixing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/21/2024 7:40:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F18', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc1b493036e360', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Deployments on QA environment.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/21/2024 7:40:48 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F19', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc1c3e6c329330', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'line approval backend and ui(production)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/21/2024 9:30:31 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F1B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc1c3e6c329341', '8/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'fixed bugs', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/21/2024 9:30:31 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F1C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc1c3e6c329352', '8/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'fixed bugs', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/21/2024 9:30:31 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F1D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc1c3e6c329363', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'fixed bugs', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/21/2024 9:30:31 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F1E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc243b75aa5d80', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Working on Line Level Approval
Apply HasAuthority for every level of approval of Line
Ensure Line Status saved and access acurately for every line approval', 0, 1, '8/22/2024 12:45:30 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/22/2024 12:45:27 AM', '8/22/2024 12:45:30 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F21', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc31c5ef763620', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Troubleshooting couple of AP works issues for production invoices to help QA', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/23/2024 2:36:20 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1F8C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3567960a5eb0', '8/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Meeting with Asim on plus Co items estimation
and updating estimates on project plan', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/23/2024 9:32:15 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1FF8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3e128ca9ea51', '8/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Tolerence on media invoices
RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/24/2024 2:04:59 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD200D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3e128ca9ea62', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', NULL, 'RE: APWorkflow: Tolerance Level Confirmation - Media/Production (NEX 16696)', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/24/2024 2:04:59 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD200E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3e456c24c020', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'APworks 
1. Media Model Mapping (create data)
2. Credit Invoices check
3. PO issues check', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/24/2024 2:27:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD201C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3e456c24c031', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'APworks 
1. Media Model Mapping (create data)
2. Credit Invoices check
3. PO issues check', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/24/2024 2:27:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD201D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3e456c24c042', '8/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'APworks
1. New build smoke testing
2. Blockers Verification
3. Media Process Run till posting
4. Verification of issues moved to testing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/24/2024 2:27:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD201E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3e65c35f5270', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'unit test on line level approval with dev', 0, 1, '8/24/2024 2:42:16 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/24/2024 2:42:13 AM', '8/24/2024 2:42:16 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2023', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3e65c35f5281', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'worked on tolerance and line level approval blockers reported', 0, 1, '8/24/2024 2:42:16 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/24/2024 2:42:13 AM', '8/24/2024 2:42:16 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2024', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc3e65c35f5292', '8/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'worked on process run on different companies during database updation', 0, 1, '8/24/2024 2:42:16 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/24/2024 2:42:13 AM', '8/24/2024 2:42:16 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2025', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc4037a9772331', '8/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'smoke testing and meeting with CEO', 0, 1, '8/24/2024 6:10:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/24/2024 6:10:40 AM', '8/24/2024 6:10:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2090', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc56e216c60440', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Working on Line Level Approval
Apply checks on saving and deleting the lines on frontend & backend for different statuses so that it can react as separately for every level', 0, 1, '8/26/2024 1:35:49 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/26/2024 1:26:37 AM', '8/26/2024 1:35:49 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2096', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc56f5008d71a0', '8/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Working on Line Level Approval in AP Works
Apply different checks related to Allow Invoice Editing and hasAuthority on different levels', 0, 1, '8/26/2024 1:35:49 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/26/2024 1:35:05 AM', '8/26/2024 1:35:49 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2097', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc56f689e001a0', '8/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Working on Bugs related to Splitting and merging the lines and also worked on Line level approval', 0, 1, '8/26/2024 1:35:49 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/26/2024 1:35:46 AM', '8/26/2024 1:35:49 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2098', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc581f0aecc050', '8/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'Project plan updates and internal discussion.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/26/2024 3:48:25 AM', '8/26/2024 3:49:19 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2113', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc5a91592fb110', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'Line Level Approval has been deployed on QA AZF environment
Bugs fixed today related to Line Level, Splitting and merging the lines', 0, 1, '8/26/2024 9:04:22 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/26/2024 8:28:38 AM', '8/26/2024 9:04:22 AM', 'arslank', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2117', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc5b321b1825e0', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Development', 'Troubleshooting deployment issue for QA AZF
System was not throwing error and not loading the document', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/26/2024 9:40:33 AM', '8/28/2024 4:52:36 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD322F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc632ffcd30740', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'line level approval production.
testing analyzing and bug fixing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/27/2024 12:55:52 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD211A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc632ffcd30751', '8/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'fixing the flow of invoice document details approval history', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/27/2024 12:55:52 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD211B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc632ffcd30762', '8/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', NULL, 'email sending on line level approval.
in auto approval case', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/27/2024 12:55:52 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD211C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc632ffcd30773', '8/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'internal meeting with ceo.
discussion with abid on requirements of email.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/27/2024 12:55:52 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD211D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc63361a1e3600', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Development', 'approval email flow setting.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/27/2024 12:58:36 AM', '8/29/2024 1:32:30 AM', 'asadm', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD33CA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc63361a1e3611', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Internal Meeting', 'about approval email flow', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/27/2024 12:58:36 AM', '8/29/2024 1:32:30 AM', 'asadm', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD33CB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc63361a1e3622', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', 'Bug Fixing', 'catering issues and removing blockers.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/27/2024 12:58:36 AM', '8/29/2024 1:32:30 AM', 'asadm', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD33CC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc63fb0aaa2c72', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'APWorks Project Plan Review', 0, 1, '8/27/2024 2:28:09 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/27/2024 2:26:42 AM', '8/27/2024 2:28:09 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD2128', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc71c3deb0a410', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Meetings', 'Plan review', 0, 1, '8/28/2024 4:47:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/28/2024 4:47:21 AM', '8/28/2024 4:47:57 AM', 'tshahzad', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4562', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc71c80976f881', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Meetings', 'Plan Review', 0, 1, '8/28/2024 4:47:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/28/2024 4:47:21 AM', '8/28/2024 4:47:57 AM', 'tshahzad', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4563', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc71e86b428100', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Bug Fixing', 'Team assistance on bug fixing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/28/2024 5:01:50 AM', '8/29/2024 8:52:03 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD351F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc71ee0b616861', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Meetings', 'Project Planning and discussion with Asim on Plus co items', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/28/2024 5:04:21 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4564', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc71f671e22230', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Meetings', 'Internal meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/28/2024 5:08:06 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4565', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc73f99f525630', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Client Items', 'Meeting with Mr. Abid Ali and team for bussiness knowledge of upcoming tasks
Abid Ali give details about tasks and also take suggestions from team', 0, 1, '8/28/2024 8:58:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/28/2024 8:58:36 AM', '8/28/2024 8:58:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD323B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc73f99f525641', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', 'Bug Fixing', 'Get hasAuthority column on PO Selection and assign it to lines on adding on splitting lines
implement front end backend changes to meet valuable results
Discussion with Mr. Arif Khan to change the procedure as well', 0, 1, '8/28/2024 8:58:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/28/2024 8:58:36 AM', '8/28/2024 8:58:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD323C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc73f99f525652', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', 'Bug Fixing', 'fixed bugs related to Merging and ByPassing the rule in Production on Saving the Lines', 0, 1, '8/28/2024 8:58:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '8/28/2024 8:58:36 AM', '8/28/2024 8:58:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD323D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7caa865175d0', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Development', 'working on async queue for send email after bulk scanning', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/29/2024 1:34:00 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD33CD', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7ce2e1e8e272', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Project Mgmt', 'Proect Setup for Plus Co Time Tracking', 0, 1, '8/29/2024 2:05:46 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/29/2024 1:59:13 AM', '8/29/2024 2:05:46 AM', 'tshahzad', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4566', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7cf00398cb02', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Meetings', 'Meeting with Imran and team on Plus Co', 0, 1, '8/29/2024 2:05:46 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/29/2024 2:05:05 AM', '8/29/2024 2:05:46 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4567', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7cf166bd23c0', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Meetings', 'Daily Dev Meeting', 0, 1, '8/29/2024 2:05:46 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'tshahzad', '8/29/2024 2:05:42 AM', '8/29/2024 2:05:46 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4568', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7de03430e180', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1.5, 'Pakistan', 'DevEng', 'Meetings', '- Internal meeting with Asim for project plan review.
- Meeting with IR, Tao and Asim on plus co items plan', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/29/2024 3:52:33 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4569', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7df1440315a0', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Bug Fixing', 'New Level2 sync issue resolved while fetching IO from screen.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/29/2024 4:00:11 AM', '8/29/2024 8:52:03 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3520', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7df1440315b1', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Internal Meeting', 'Emails
Internal Team meetings.
Merging all production fixes to azf branch and resloved all conflicts.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/29/2024 4:00:11 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD351B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7df1440315c2', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Development', 'Applied timeout to 120 seconds for SP calls', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/29/2024 4:00:11 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD351C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc7df608250040', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Deployment', 'AP works: Deployment for production item', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/29/2024 4:02:19 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3EC2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc807da65f5ad2', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1.5, 'Pakistan', 'DevEng', 'Deployment', 'Application and Database SPs deployment as ArifK is on leave today.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/29/2024 8:52:03 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3EC3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc807da65f5ae3', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Meetings', 'Internal Meeting on Plus Co items and Plan
Meeting with IR and Tao', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/29/2024 8:52:03 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD456A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc807da65f5af4', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Project Mgmt', 'Project Plan adjustments and moving tasks into multiple sprints and resource allocation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '8/29/2024 8:52:03 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD456B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc88b6e89a0ec0', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Internal Meeting', 'discussion about issues', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/30/2024 12:33:56 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3526', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc88b6e89a0ed1', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Internal Meeting', 'discussion about issues', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/30/2024 12:33:56 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3527', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc88b6e89a0ee2', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', 'Bug Fixing', 'bug fixing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/30/2024 12:33:56 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3528', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc88b6e89a0ef3', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', 'Bug Fixing', 'bug fixing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/30/2024 12:33:56 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3529', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc88b6e89a0f04', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 6, 'Pakistan', 'DevEng', 'Bug Fixing', 'bug fixing in sprint 2 of apworks', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/30/2024 12:33:56 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD352A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cc4208da966', '8/26/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Testing', 'Re: ApWorks Azure AI Deployment 2024.2
Performed QA testing and troubleshooting for a critical blocker issue. Conducted detailed analysis, identified root cause, and collaborated with the development team to ensure resolution', 0, 1, '9/13/2024 2:20:58 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/30/2024 8:17:58 AM', '9/13/2024 2:20:58 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4A7E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cc4208da977', '8/27/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Testing', 'RE: ApWorks Azure AI Deployment 2024.2
Worked on blockers testing', 0, 1, '9/13/2024 2:20:58 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/30/2024 8:17:58 AM', '9/13/2024 2:20:58 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4A7F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cc4208da988', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', 'Testing', 'FW: Dashboard Loading Error
Worked on QA02. Process media and non media on QA02.', 0, 1, '9/13/2024 2:20:58 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/30/2024 8:17:58 AM', '9/13/2024 2:20:58 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4A80', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cc4208da999', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Testing', 'RE: ApWorks Azure AI Deployment 2024.2
Worked on Auto Approval and split functionality', 0, 1, '9/13/2024 2:20:58 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/30/2024 8:17:58 AM', '9/13/2024 2:20:58 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4A81', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cde74a7c8a0', '8/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', NULL, 'APworks
1. New build smoke testing
2. Blockers Verification
3. Media Process Run till posting
4. Verification of issues moved to testing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:29:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD360F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8ce0ad808ba0', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', 'Analysis', 'Unit testing on line level approval', 0, 1, '8/30/2024 8:30:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/30/2024 8:30:45 AM', '8/30/2024 8:30:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3617', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8ce0ad808bb1', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Analysis', 'discuss with dev team on bugs', 0, 1, '8/30/2024 8:30:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/30/2024 8:30:45 AM', '8/30/2024 8:30:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3618', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8ce0ad808bc2', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', 'Testing', 'reported blockers and emailed it to lead and the dev team', 0, 1, '8/30/2024 8:30:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/30/2024 8:30:45 AM', '8/30/2024 8:30:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3619', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8ce0ad808bd3', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', 'Testing', 'ticket moved back to dev team for re occuring of bugs', 0, 1, '8/30/2024 8:30:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/30/2024 8:30:45 AM', '8/30/2024 8:30:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD361A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8ce0ad808be4', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', 'Testing', 'new build checked and reported back to dev team for fixes', 0, 1, '8/30/2024 8:30:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/30/2024 8:30:45 AM', '8/30/2024 8:30:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD361B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8ce0ad808bf5', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Testing', 'tickets generated and bugs closed in the latest build', 0, 1, '8/30/2024 8:30:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/30/2024 8:30:45 AM', '8/30/2024 8:30:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD361C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8ce0ad808c06', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', 'Testing', 'recheck the broken flows on missing documentation items and reported blockers', 0, 1, '8/30/2024 8:30:48 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/30/2024 8:30:45 AM', '8/30/2024 8:30:48 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD361D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52c80', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'Standup meeting and internal meetings for progress', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD369C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52c91', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'Standup meeting and internal meetings for progress', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD369D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52ca2', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'Standup meeting and internal meetings for progress', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD369E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52cb3', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'Standup meeting and internal meetings for progress', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD369F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52cc4', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'Standup meeting and internal meetings for progress', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36A0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52cd5', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', 'Testing', 'APworks modules: 
1. Merging
2. Split
3. Line Level Approval
4. Model Mapping', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36A1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52ce6', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', 'Testing', 'APworks modules: 
1. Merging
2. Split
3. Line Level Approval
4. Model Mapping', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:36 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36A2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52cf7', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', 'Testing', 'APworks modules: 
1. Merging
2. Split
3. Line Level Approval
4. Model Mapping', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:36 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36A3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52d08', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', 'Testing', 'APworks modules: 
1. Merging
2. Split
3. Line Level Approval
4. Model Mapping', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:36 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36A4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8cf8ecd52d19', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 7, 'Pakistan', 'DevEng', 'Testing', 'APworks modules: 
1. Merging
2. Split
3. Line Level Approval
4. Model Mapping', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'ayeshaq', '8/30/2024 8:41:36 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36A5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d0bf2ef93d0', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Internal Meeting', 'meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 8:50:06 AM', '8/30/2024 9:14:13 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD455D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d12476f6a43', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Internal Meeting', 'Meeting with team on Progress, bugs and detailed analysis.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 8:52:56 AM', '8/30/2024 8:53:09 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36B3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d12476f6a54', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'Meeting with team on Progress, bugs and detailed analysis.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 8:52:56 AM', '8/30/2024 8:53:09 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36B4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d12476f6a65', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 8:52:56 AM', '8/30/2024 8:53:09 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36B5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d12476f6a76', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Internal Meeting', 'meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 8:52:56 AM', '8/30/2024 9:14:13 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36B8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d12476f6a87', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'meetingsmeetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 8:52:56 AM', '8/30/2024 8:53:09 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36B7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d41d595c321', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', 'Testing', 'Review ot Phase 2 tems in QA', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 9:14:13 AM', '8/30/2024 9:41:59 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36C1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d41d595c332', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', 'Testing', 'Review ot Phase 2 tems in QA', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 9:14:13 AM', '8/30/2024 9:41:59 AM', 'bilala', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36C2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d41d595c343', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Internal Meeting', 'meetings', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '8/30/2024 9:14:13 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD455E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d771c2308a0', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', 'Internal Meeting', 'internal meeting about issues and plans.', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/30/2024 9:38:03 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36BE', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcc8d771c2308b1', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', 'Bug Fixing', 'bug fixing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asadm', '8/30/2024 9:38:03 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD36BF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcca1f457890310', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Deployment', 'APworks QA upgrade', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '9/1/2024 12:44:43 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3EC4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcca1f457890321', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Meetings', 'Team support and reviewed sprint #2 tasks', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'abida', '9/1/2024 12:44:43 AM', '9/3/2024 1:26:00 AM', 'abida', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD456C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dccb14c86262130', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', 'Bug Fixing', 'Fix bugs generated by QA team to handle Line Level Approval and verify some cases
Worked on Database for Authority on stored procedures to get valuable results', 0, 1, '9/2/2024 6:04:46 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '9/2/2024 6:02:10 AM', '9/2/2024 6:04:46 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3E12', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dccb15219cdf310', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', 'Bug Fixing', 'Fix some bugs test the changes and deploy the package in the QA environment', 0, 1, '9/2/2024 6:04:46 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arslank', '9/2/2024 6:04:39 AM', '9/2/2024 6:04:46 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD3E13', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dccb33e0b219192', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Project Mgmt', 'ApWorks review', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'Tshahzad', '9/2/2024 9:44:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD456D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf24798aafc410', '8/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Research', 'R&D on EDI File Processing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arshads', '10/22/2024 3:14:09 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD84EA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf24798aafc421', '8/27/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Research', 'R&D on EDI File Processing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arshads', '10/22/2024 3:14:09 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD84EB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf24798aafc432', '8/28/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', 'Research', 'R&D on EDI File Processing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arshads', '10/22/2024 3:14:09 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD84EC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf24798aafc443', '8/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Research', 'R&D on EDI File Processing', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'arshads', '10/22/2024 3:14:09 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD84ED', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf248a903e3c70', '8/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', 'Documentation', 'Requirement Specifications', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:22:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD8619', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf248c89a4dc71', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', 'Documentation', 'Requirement Specifications', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:22:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD861A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf248c89a4dc82', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', 'Documentation', 'Requirement Specifications', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:22:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD861B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf248c89a4dc93', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Documentation', 'Requirement Specifications', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:22:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD861C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf248c89a4dca4', '8/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', 'Documentation', 'Requirement Specifications', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:22:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD861D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf248c89a4dcb5', '8/20/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 8, 'Pakistan', 'DevEng', 'Analysis', 'Review PlusCo requirements document', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:22:39 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD861E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf2490d4f684a0', '7/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Analysis', 'Analysis of PlusCo requirements', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:25:28 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89C7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf2492d5fdcaf1', '7/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Analysis', 'Analysis of PlusCo requirements', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:25:28 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89C8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf2492d5fdcb02', '7/26/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Analysis', 'Analysis of PlusCo requirements', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:25:28 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89C9', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249595e12da0', '6/17/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Analysis', 'Requirement Analysis and Documentation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:26:42 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89CA', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249595e12db1', '6/18/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Analysis', 'Requirement Analysis and Documentation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:26:42 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89CB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249595e12dc2', '6/19/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Analysis', 'Requirement Analysis and Documentation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:26:42 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89CC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249595e12dd3', '6/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Analysis', 'Requirement Analysis and Documentation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:26:42 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89CD', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249a2bb7af20', '6/10/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', 'Analysis', 'Requirement Analysis and Documentation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:28:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89CE', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249a2bb7af31', '6/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Analysis', 'Requirement Analysis and Documentation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:28:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89CF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249a2bb7af42', '6/14/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Analysis', 'Requirement Analysis and Documentation', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:28:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89D0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249a2bb7af53', '6/11/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Meetings', 'Discuss Plus Co requirement Implementation Plan', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:28:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89D1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249a2bb7af64', '6/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Meetings', 'Discuss Plus Co requirement Implementation Plan', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:28:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89D2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', '8dcf249a2bb7af75', '6/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', 'Meetings', 'Discuss Plus Co requirement Implementation Plan', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'asimj', '10/22/2024 3:28:45 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD89D3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf7fcb78588810', '7/4/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'RE: ApWorks Azure AI Deployment 2024.2', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'bilala', '7/29/2024 3:37:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0078', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8cf10', '6/4/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD021B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8d011', '6/5/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD021C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8d112', '6/6/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD021D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8d213', '6/7/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD021E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8d314', '6/3/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD021F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8d415', '6/4/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0220', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8d516', '6/5/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0221', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8d617', '6/6/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0222', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83b469d8d718', '6/7/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:38 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0223', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947010', '6/11/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0233', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947111', '6/12/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0234', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947212', '6/13/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0235', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947313', '6/14/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0236', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947414', '6/10/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0237', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947515', '6/11/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0238', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947616', '6/12/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0239', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947717', '6/13/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD023A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf83ba2b947818', '6/14/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:05:47 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD023B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9904910', '6/18/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD024B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9904a11', '6/19/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD024C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9904b12', '6/20/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD024D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9904c13', '6/21/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD024E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9904d14', '6/17/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD024F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9904e15', '6/18/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0250', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9904f16', '6/19/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0251', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9905017', '6/20/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0252', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf8415e9905118', '6/21/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:21 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0253', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb994f10', '6/25/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0263', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb995011', '6/26/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0264', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb995112', '6/27/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0265', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb995213', '6/28/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0266', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb995314', '6/24/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0267', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb995415', '6/25/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0268', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb995516', '6/26/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0269', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb995617', '6/27/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD026A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf841dcb995718', '6/28/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 0, NULL, 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:08:35 AM', NULL, NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD026B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65167d10', '7/2/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD177B', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65167e11', '7/3/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD177C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65167f12', '7/4/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD177D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65168013', '7/5/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD177E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65168114', '7/1/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD177F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65168215', '7/2/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1780', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65168316', '7/3/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1781', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65168417', '7/4/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1782', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf847b65168518', '7/5/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 8:53:03 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:11:12 AM', '8/19/2024 8:53:03 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1783', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7b610', '7/9/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1692', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7b711', '7/10/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1693', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7b812', '7/11/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1694', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7b913', '7/12/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1695', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7ba14', '7/8/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1696', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7bb15', '7/9/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1697', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7bc16', '7/10/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1698', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7bd17', '7/11/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1699', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854601a7be18', '7/12/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:46:42 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:16:52 AM', '8/19/2024 6:46:42 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD169A', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44210', '7/16/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16BF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44311', '7/17/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16C0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44412', '7/18/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16C1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44513', '7/19/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16C2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44614', '7/15/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'Phase 1 testing', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16C3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44715', '7/16/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 testing', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16C4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44816', '7/17/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'vendor mapping issues reporting and closing of bugs in azure', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16C5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44917', '7/18/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16C6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf854f56f44a18', '7/19/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 5, 'Pakistan', 'DevEng', NULL, 'UI changes testing and reporting', 0, 1, '8/19/2024 6:52:36 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:17:07 AM', '8/19/2024 6:52:36 AM', 'kashifh', 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD16C7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93710', '7/23/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02DD', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93811', '7/24/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02DE', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93912', '7/25/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02DF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93a13', '7/26/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02E0', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93b14', '7/22/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02E1', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93c15', '7/23/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02E2', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93d16', '7/24/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02E3', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93e17', '7/25/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02E4', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcaf85b294e93f18', '7/26/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting', 0, 1, '7/29/2024 4:19:57 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '7/29/2024 4:19:54 AM', '7/29/2024 4:19:57 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD02E5', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a95910', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E6', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a95a11', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E7', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a95b12', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E8', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a95c13', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'unit testing with abid and imran', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07E9', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a95d14', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'QA items closing on azure', 0, 1, '8/19/2024 6:43:26 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/19/2024 6:43:26 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1687', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a95e15', '7/29/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07EB', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a95f16', '7/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07EC', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a96017', '7/31/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07ED', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a96118', '8/1/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'AZF phase 1 requirement analysis 
test cases according to the document and flow 
discussion with the lead over major changes 
documentation analysis over the new changes and impact of these items over the APworks enviorment
Taxes addition issues with taxes +CRUD method validation from database and from UI 
Currency addition and CRUD method verification
Phase 2
 implementation and requirement analysis 
shipyard nexelus + apworks compele flow and and issue reporting
document reading for new items 
fixed for client issues', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07EE', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcb50c18f1a96219', '8/2/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', NULL, 'unit testing with abid and imran', 0, 1, '8/5/2024 5:04:39 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/5/2024 5:04:34 AM', '8/5/2024 5:04:39 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD07EF', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbb7596fd75ca10', '8/5/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'document writing as release notes', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F2C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbb7596fd75cb11', '8/6/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'document writing as release notes', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F2D', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbb7596fd75cc12', '8/7/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 4, 'Pakistan', 'DevEng', NULL, 'phase 3 planning and test cases
closing QA items + document working 
flow corrections + item review
document writing as release notes', 0, 1, '8/13/2024 8:54:54 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/13/2024 8:54:49 AM', '8/13/2024 8:54:54 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD0F2E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be010', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD104E', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be111', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases', 0, 1, '8/19/2024 6:33:04 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/19/2024 6:33:04 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1673', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be212', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process', 0, 1, '8/19/2024 6:33:04 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/19/2024 6:33:04 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1674', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be313', '8/14/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/19/2024 6:33:04 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/19/2024 6:33:04 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1675', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be414', '8/15/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/19/2024 6:33:04 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/19/2024 6:33:04 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1676', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be515', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
release notes with hamza
QA blockers reported on email + azure', 0, 1, '8/19/2024 6:33:04 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/19/2024 6:33:04 AM', 'kashifh', 0, '', 0, '', NULL, 'Please update comments properly', 'bilala', NULL, NULL, '0x000000006BDD1677', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be616', '8/12/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1054', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be717', '8/13/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 1, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1055', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcbdc5c16e1be818', '8/16/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', NULL, 'phase 3 line level approval document review with team and generated test cases
team meeting discussion of bug items
validating and checking QA enviroment for defects by smoke testing
tickets recheck for QA process
worked on release notes documents with hamza', 0, 1, '8/16/2024 7:33:47 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'kashifh', '8/16/2024 7:33:43 AM', '8/16/2024 7:33:47 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD1056', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcc7cf602363f318', '8/19/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Testing', 'Re: ApWorks Azure AI Deployment 2024.2
Performed QA testing and troubleshooting for a critical blocker issue. Conducted detailed analysis, identified root cause, and collaborated with the development team to ensure resolution', 0, 1, '8/29/2024 2:08:51 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/29/2024 2:08:47 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, '', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6784', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcc7cf602363f419', '8/20/2024 12:00:00 AM', '0', 1004, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Testing', 'FW: Japan Testing: Rounding Issue on Tax Amount + Additional issues
Worked on Tax Amount and Additional Issues', 0, 1, '8/29/2024 2:08:51 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/29/2024 2:08:47 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, '', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6786', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcc7cf602363f520', '8/21/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Testing', 'Re: Japan Testing: Rounding Issue on Tax Amount + Additional issues
Worked on Tax Amount and Additional Issues', 0, 1, '8/29/2024 2:08:51 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/29/2024 2:08:47 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, '', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6789', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcc7cf602363f621', '8/22/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Testing', 'FW: Japan Testing: Rounding Issue on Tax Amount + Additional issues
Worked on Tax Amount and Additional Issues', 0, 1, '8/29/2024 2:08:51 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/29/2024 2:08:47 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, '', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD678C', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcc7cf602363f722', '8/23/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Testing', 'RE: ApWorks Azure AI Deployment 2024.2
Worked on Expanding Dashboard layout to full screen for each gadget and page count to 25 per page.', 0, 1, '8/29/2024 2:08:51 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/29/2024 2:08:47 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, '', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD678F', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcc7cf602363f823', '8/24/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 3, 'Pakistan', 'DevEng', 'Testing', 'Worked on Tolerance for Media on APWorks and tested it with a discussion on an issue with team and conclude it was not an issue (Related to Tax)', 0, 1, '8/29/2024 2:08:51 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/29/2024 2:08:47 AM', '10/1/2024 1:44:27 AM', 'bilala', 0, '', 0, '', NULL, '', 'bilala', '10/1/2024 1:44:27 AM', NULL, '0x000000006BDD6792', NULL, NULL, NULL, NULL, NULL, NULL), 
(1, 'ps000457 ', 'Time Billable', 'dcc8cc4208da9a10', '8/30/2024 12:00:00 AM', '0', 1001, 'DEVELOPMENT', 'Development', 2, 'Pakistan', 'DevEng', 'Testing', 'RE: ApWorks Azure AI Deployment 2024.2
Worked on Split and Merging Functionalities', 0, 1, '9/13/2024 2:20:58 AM', 0, NULL, NULL, ' ', 0, '', ' ', 0, 0, 0, 0, 0, 0, 0, ' ', ' ', 0, 'hamzan', '8/30/2024 8:17:58 AM', '9/13/2024 2:20:58 AM', NULL, 0, '', 0, '', NULL, NULL, NULL, NULL, NULL, '0x000000006BDD4A82', NULL, NULL, NULL, NULL, NULL, NULL)